import random

while True:
 choices = ["r", "p", "s"]

 computer = random.choice(choices)
 player = None

 while player not in choices:
     player = input("r, p or s?: ").lower()

 if player == computer:
     print("computer: ", computer)
     print("player: ", player)
     print("Tie!")
 elif player == "r":
     if computer == "p":
         print("computer: ", computer)
         print("player: ", player)
         print("You lose!")
     if computer == "s":
         print("computer: ", computer)
         print("player: ", player)
         print("You Win!")
 elif player == "s":
         if computer == "p":
             print("computer: ", computer)
             print("player: ", player)
             print("You Win!")
         if computer == "r":
             print("computer: ", computer)
             print("player: ", player)
             print("You Lose!")
 elif player == "p":
         if computer == "r":
                print("computer: ", computer)
                print("player: ", player)
                print("You Win!")
         if computer == "s":
                print("computer: ", computer)
                print("player: ", player)
                print("You Lose!")

 play_again = input("Play again? (yes/no): ").lower()

 if play_again != "yes":
     break
print("Bye!")






